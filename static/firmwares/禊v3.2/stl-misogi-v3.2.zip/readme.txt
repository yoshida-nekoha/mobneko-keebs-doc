1. ProMicro/BMP 共通
'misogi-v3.2 bottom.stl'
'misogi-v3.2 switch.stl'

2. ProMicroケース
'misogi-v3.2 top-PM.stl'

3. BMP開放型
'misogi-v3.2 top-BMP-open.stl'

4. BMPフタ付き
'misogi-v3.2 top-BMP-closed1.stl'
'misogi-v3.2 top-BMP-closed2.stl'
